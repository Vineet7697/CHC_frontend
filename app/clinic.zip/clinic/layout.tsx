import AppShell from "@/components/layout/AppShell";

export default function ClinicLayout({ children }: { children: React.ReactNode }) {
  return (
    <AppShell role="clinic" userName="Meera Joshi" meta="Pharmacist · Ground Floor Counter">
      {children}
    </AppShell>
  );
}
