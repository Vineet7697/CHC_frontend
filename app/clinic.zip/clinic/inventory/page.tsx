import InventoryView from "@/components/inventory/InventoryView";

export default function ClinicInventoryPage() {
  return <InventoryView editable />;
}
