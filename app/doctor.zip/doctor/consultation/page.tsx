"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowRight, FileText, Users } from "lucide-react";

import { doctorService, type CurrentPatient } from "@/services/doctorservice";
import { Panel } from "@/components/cards/Card";
import { MiniTokenChip } from "@/components/token/TokenBoard";
import { TextAreaField } from "@/components/forms/Field";
import { EmptyState } from "@/components/common/States";

export default function DoctorConsultationPage() {
  const [currentPatient, setCurrentPatient] = useState<CurrentPatient | null>(
    null,
  );

  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function loadCurrentPatient() {
    try {
      setLoading(true);
      setError("");

      const response = await doctorService.getCurrentPatient();

      setCurrentPatient(response?.data ?? null);
    } catch (error: any) {
      console.error("Current patient API error:", error);

      // Backend returns 404 when there is no patient
      if (error?.response?.status === 404) {
        setCurrentPatient(null);
        return;
      }

      setError(
        error?.response?.data?.message || "Unable to load current patient",
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadCurrentPatient();
  }, []);

  // Loading
  if (loading) {
    return (
      <Panel>
        <div className="py-10 text-center text-sm text-slate-500">
          Loading current patient...
        </div>
      </Panel>
    );
  }

  // API error
  if (error) {
    return (
      <Panel>
        <div className="py-10 text-center">
          <p className="text-sm text-red-500">{error}</p>

          <button
            onClick={loadCurrentPatient}
            className="mt-4 inline-flex items-center justify-center gap-1.5 bg-teal-800 text-white text-sm font-semibold rounded-lg px-4 py-2.5 hover:bg-teal-900"
          >
            Retry
          </button>
        </div>
      </Panel>
    );
  }

  // No patient
  if (!currentPatient) {
    return (
      <Panel>
        <EmptyState
          icon={Users}
          title="No patient in consultation"
          description="Call the next patient from the queue to start a consultation."
          action={
            <Link
              href="/doctor/patients"
              className="inline-flex items-center gap-1.5 bg-teal-800 text-white text-sm font-semibold rounded-lg px-4 py-2.5 hover:bg-teal-900"
            >
              Go to patient queue
              <ArrowRight size={14} />
            </Link>
          }
        />
      </Panel>
    );
  }

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Page heading */}
      <div>
        <h1 className="font-display text-2xl font-bold text-ink">
          Current patient
        </h1>

        <p className="text-sm text-slate-500 mt-1">
          Review the patient, then move to prescription.
        </p>
      </div>

      {/* Patient information */}
      <Panel>
        <div className="flex items-center gap-4 pb-5 mb-5 border-b border-line">
          <MiniTokenChip code={`T-${currentPatient.token_number}`} />

          <div className="flex-1">
            <p className="font-display font-semibold text-ink text-[15px]">
              {currentPatient.name}
            </p>

            <p className="text-xs text-slate-500 mt-0.5">
              {currentPatient.patient_id} · {currentPatient.age} yrs ·{" "}
              {currentPatient.gender}
            </p>
          </div>
        </div>

        {/* Consultation notes */}
        <TextAreaField
          id="notes"
          label="Consultation notes"
          placeholder="Symptoms, observations, diagnosis..."
          rows={5}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          hint="Notes stay with this visit and are visible only to hospital staff."
        />

        {/* Prescription */}
        <Link
          href={`/doctor/prescription?tokenId=${currentPatient.token_id}`}
          className="inline-flex items-center gap-2 bg-teal-800 text-white text-sm font-semibold rounded-lg px-5 py-2.5 hover:bg-teal-900"
        >
          <FileText size={15} />
          Proceed to prescription
        </Link>
      </Panel>
    </div>
  );
}
