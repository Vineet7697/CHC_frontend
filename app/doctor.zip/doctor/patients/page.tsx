"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { PhoneCall, Pause, SkipForward, RotateCw } from "lucide-react";

import { doctorService, type DoctorPatient } from "@/services/doctorservice";

import { Panel } from "@/components/cards/Card";
import DataTable, { Column } from "@/components/tables/DataTable";
import StatusBadge from "@/components/badges/StatusBadge";
import { MiniTokenChip } from "@/components/token/TokenBoard";
import { useToast } from "@/components/common/Toast";

export default function DoctorPatientsPage() {
  const router = useRouter();
  const { show } = useToast();

  const [patients, setPatients] = useState<DoctorPatient[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [actionLoading, setActionLoading] = useState<number | null>(null);

  const [callingNext, setCallingNext] = useState(false);

  // ========================================
  // LOAD QUEUE
  // ========================================

  async function loadPatients() {
    try {
      setLoading(true);
      setError("");

      const response = await doctorService.getPatients();

      setPatients(response?.data ?? []);
    } catch (error: any) {
      console.error("GET /doctor/patients error:", error);

      setError(
        error?.response?.data?.message || "Unable to load patient queue",
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadPatients();
  }, []);

  // ========================================
  // CURRENT CONSULTATION
  // ========================================

  const hasActiveConsultation = useMemo(() => {
    return patients.some((patient) => patient.status === "IN_CONSULTATION");
  }, [patients]);

  // ========================================
  // HOLD / SKIP / RECALL
  // ========================================

  async function handleAction(
    tokenId: number,
    action: "hold" | "skip" | "recall",
  ) {
    try {
      setActionLoading(tokenId);

      let response;

      if (action === "hold") {
        response = await doctorService.holdPatient(tokenId);
      }

      if (action === "skip") {
        response = await doctorService.skipPatient(tokenId);
      }

      if (action === "recall") {
        response = await doctorService.recallPatient(tokenId);
      }

      show(
        action === "skip" ? "info" : "success",
        response?.message ||
          (action === "hold"
            ? "Patient placed on hold"
            : action === "skip"
              ? "Patient skipped"
              : "Patient recalled"),
      );

      await loadPatients();
    } catch (error: any) {
      console.error(`${action} patient error:`, error);

      show(
        "error",
        error?.response?.data?.message || `Unable to ${action} patient`,
      );
    } finally {
      setActionLoading(null);
    }
  }

  // ========================================
  // CALL NEXT
  // ========================================

  async function handleCallNext() {
    try {
      setCallingNext(true);

      const response = await doctorService.callNext();

      show("success", response?.message || "Next patient called");

      // Refresh queue
      await loadPatients();

      // Go to consultation
      router.push("/doctor/consultation");
    } catch (error: any) {
      console.error("POST /doctor/call-next error:", error);

      show(
        "error",
        error?.response?.data?.message || "Unable to call next patient",
      );
    } finally {
      setCallingNext(false);
    }
  }

  // ========================================
  // TABLE COLUMNS
  // ========================================

  const columns: Column<DoctorPatient>[] = [
    {
      header: "Token",
      accessor: (patient) => (
        <MiniTokenChip code={`T-${patient.token_number}`} />
      ),
    },

    {
      header: "Patient ID",
      accessor: (patient) => (
        <span className="text-slate-500">{patient.patient_id}</span>
      ),
    },

    {
      header: "Name",
      accessor: (patient) => (
        <span className="font-medium text-ink">{patient.patient_name}</span>
      ),
    },

    {
      header: "Age",
      accessor: (patient) => patient.age,
    },

    {
      header: "Gender",
      accessor: (patient) => patient.gender,
    },

    {
      header: "Status",
      accessor: (patient) => <StatusBadge status={patient.status} />,
    },

    {
      header: "Action",

      accessor: (patient) => {
        const isLoading = actionLoading === patient.token_id;

        // WAITING
        if (patient.status === "WAITING") {
          return <span className="text-xs text-slate-400">Awaiting call</span>;
        }

        // IN CONSULTATION
        if (patient.status === "IN_CONSULTATION") {
          return (
            <div className="flex gap-1.5">
              <button
                disabled={isLoading}
                onClick={() => handleAction(patient.token_id, "hold")}
                className="text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-line text-slate-600 hover:bg-teal-50 flex items-center gap-1 disabled:opacity-50"
              >
                <Pause size={12} />

                {isLoading ? "..." : "Hold"}
              </button>

              <button
                disabled={isLoading}
                onClick={() => handleAction(patient.token_id, "skip")}
                className="text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-line text-slate-600 hover:bg-teal-50 flex items-center gap-1 disabled:opacity-50"
              >
                <SkipForward size={12} />

                {isLoading ? "..." : "Skip"}
              </button>
            </div>
          );
        }

        // HOLD / SKIPPED
        if (patient.status === "HOLD" || patient.status === "SKIPPED") {
          return (
            <button
              disabled={isLoading}
              onClick={() => handleAction(patient.token_id, "recall")}
              className="text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-teal-800/30 text-teal-800 hover:bg-teal-50 flex items-center gap-1 disabled:opacity-50"
            >
              <RotateCw size={12} />

              {isLoading ? "..." : "Recall"}
            </button>
          );
        }

        return <span className="text-xs text-slate-400">—</span>;
      },
    },
  ];

  // ========================================
  // LOADING
  // ========================================

  if (loading) {
    return (
      <div className="space-y-6">
        <Panel>
          <div className="py-10 text-center text-sm text-slate-500">
            Loading patient queue...
          </div>
        </Panel>
      </div>
    );
  }

  // ========================================
  // ERROR
  // ========================================

  if (error) {
    return (
      <div className="space-y-6">
        <Panel>
          <div className="py-10 text-center">
            <p className="text-sm text-red-500">{error}</p>

            <button
              onClick={loadPatients}
              className="mt-4 inline-flex items-center justify-center bg-teal-800 text-white text-sm font-semibold rounded-lg px-4 py-2.5 hover:bg-teal-900"
            >
              Retry
            </button>
          </div>
        </Panel>
      </div>
    );
  }

  // ========================================
  // PAGE
  // ========================================

  const room = patients[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink">
            Patient queue
          </h1>

          <p className="text-sm text-slate-500 mt-1">
            Room {room?.room_number ?? "—"} · {room?.room_name ?? "—"}
          </p>
        </div>

        <button
          onClick={handleCallNext}
          disabled={hasActiveConsultation || callingNext}
          title={
            hasActiveConsultation
              ? "Complete or hold the current consultation first"
              : undefined
          }
          className="inline-flex items-center justify-center gap-2 bg-teal-800 text-white text-sm font-semibold rounded-lg px-5 py-2.5 hover:bg-teal-900 disabled:opacity-40"
        >
          <PhoneCall size={15} />

          {callingNext ? "Calling..." : "Call next"}
        </button>
      </div>

      {/* Queue */}
      <Panel className="!p-0">
        <DataTable
          rows={patients}
          rowKey={(patient) => String(patient.token_id)}
          columns={columns}
          searchKeys={(patient) =>
            `${patient.token_number} ${patient.patient_name} ${patient.patient_id}`
          }
          searchPlaceholder="Search by token, patient name or ID"
          filters={[
            {
              label: "All",
              value: "ALL",
            },
            {
              label: "Waiting",
              value: "WAITING",
            },
            {
              label: "In consultation",
              value: "IN_CONSULTATION",
            },
            {
              label: "Hold",
              value: "HOLD",
            },
            {
              label: "Skipped",
              value: "SKIPPED",
            },
            {
              label: "Completed",
              value: "COMPLETED",
            },
          ]}
          filterFn={(patient, value) =>
            value === "ALL" ||
            patient.status === value ||
            (value === "COMPLETED" &&
              ["COMPLETED", "MEDICINE_PENDING", "MEDICINE_COMPLETED"].includes(
                patient.status,
              ))
          }
          emptyTitle="No patients in this view"
          emptyDescription="Try a different filter or search term."
        />
      </Panel>
    </div>
  );
}
